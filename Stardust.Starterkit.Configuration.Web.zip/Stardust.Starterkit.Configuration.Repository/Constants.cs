﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stardust.Starterkit.Configuration.Repository
{
   public sealed class Constants
   {
       public const string KeyValidator = @"^[0-9a-zA-Z_|''-'\s]{1,40}$";
   }
}
