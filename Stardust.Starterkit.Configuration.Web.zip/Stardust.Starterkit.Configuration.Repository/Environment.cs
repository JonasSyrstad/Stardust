﻿using System;
using System.Collections.Generic;
using System.Linq;
using Stardust.Interstellar.ConfigurationReader;
using Stardust.Wormhole;

namespace Stardust.Starterkit.Configuration.Repository
{
    public partial class Environment
    {
        public override string ToString()
        {
            return Id;
        }

        public EnvironmentConfig GetRawConfigData()
        {
            return new EnvironmentConfig
            {
                EnvironmentName = Name,
                Parameters = (from p in EnvironmentParameters select p.GetRawConfigData()).ToList(),
                Cache = CacheType.Map().To<Interstellar.ConfigurationReader.CacheSettings>()
            };
        }

        public IdentitySettings GetRawIdentityData()
        {
            return new IdentitySettings
            {
                Audiences = new List<string> {GetValue("Realm")},
                IssuerName = GetValue("IssuerName"),
                CertificateValidationMode = GetValue("CertificateValidationMode"),
                EnforceCertificateValidation = GetValue("EnforceCertificateValidation").Equals("true",StringComparison.CurrentCultureIgnoreCase),
                IssuerAddress = GetValue("StsAddress"),
                Thumbprint = GetValue("Thumbprint"),
                Realm = GetValue("Realm"),
                RequireHttps = GetValue("RequireHttps").Equals("true", StringComparison.CurrentCultureIgnoreCase)

            }; 
        }

        private string GetValue(string key)
        {
            return SubstitutionParameters.Single(x => x.Name == key).Value;
        }
    }
}