using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using Stardust.Particles;
using Stardust.Nucleus;

namespace Stardust.Starterkit.Configuration.Repository
{
    public partial class EndpointParameter
    {
        public override string ToString()
        {
            return Id;
        }

        private Dictionary<string, string> EnvironmentalValueCache;
        public string Value
        {
            get
            {
                if (ItemValue == null)
                {
                    return Parent == null ? "" : Parent.Value;
                }
                return ItemValue;
            }
        }

        public Dictionary<string, string> EnvironmentalValue
        {
            get
            {
                if (EnvironmentalValueCache == null)
                {
                    BuildEnvironmentSubstitutionCache();
                }
                return EnvironmentalValueCache;
            }
        }

        public bool IsRoot { get { return Parent == null; } }

        private void BuildEnvironmentSubstitutionCache()
        {
            EnvironmentalValueCache = new Dictionary<string, string>();
            foreach (var environment in Endpoint.ServiceDescription.ConfigSet.Environments)
            {
                var substitute = "";
                if (IsPerService)
                    substitute = GetPerServiceSubstituteValue(environment);
                else
                    substitute = GetSubstituteValue(environment, substitute);
                EnvironmentalValueCache.Add(environment.Name, substitute);
            }
        }

        private string GetSubstituteValue(IEnvironment environment, string substitute)
        {
            if (Value == null) return substitute;
            var val = environment.SubstitutionParameters.FirstOrDefault(x => x.Name == Name);
            substitute = string.Format(Value, val != null ? val.Value : null);
            return substitute;
        }

        private string GetPerServiceSubstituteValue(IEnvironment environment)
        {
            var subValueName = string.Format("{0}_{1}", Endpoint.ServiceDescription.Name, Name);
            var subValue = environment.SubstitutionParameters.SingleOrDefault(x => x.Name == subValueName);
            var substitute = "";
            if (subValue != null)
            {
                substitute = string.Format(Value, subValue.Value);
            }
            else
            {
                CreateSubstitutionParameterForEnvironment(environment, subValueName);
            }
            return substitute;
        }

        public static void CreateSubstitutionParameterForEnvironment( IEnvironment environment, string subValueName)
        {
            ConfigurationContext context;
            CreateSubstitutionParameterCore(environment, subValueName, out context);
            context.SaveChanges();
        }

            private static ISubstitutionParameter CreateSubstitutionParameterCore(IEnvironment environment, string subValueName,
                out ConfigurationContext context)
            {
                context = (ConfigurationContext) ContainerFactory.Current.Resolve(typeof (ConfigurationContext), Scope.Context);
                if (context.IsNull()) throw new CommunicationException("Unable to get database");
                var subValue = context.SubstitutionParameters.Create();
                subValue.Name = subValueName;
                subValue.Environment = environment;
                subValue.EnvironmentNameId = environment.Id;
                return subValue;
            }

        public static void CreateSubstitutionParameterForEnvironment(IEnvironment environment, string subValueName, string itemValue)
        {
            ConfigurationContext context;
            var supParam=CreateSubstitutionParameterCore(environment, subValueName, out context);
            supParam.ItemValue = itemValue;
            context.SaveChanges();
        }
    }
}