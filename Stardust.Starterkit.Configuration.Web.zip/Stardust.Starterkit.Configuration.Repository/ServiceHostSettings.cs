﻿using System.Linq;
using Stardust.Interstellar.ConfigurationReader;

namespace Stardust.Starterkit.Configuration.Repository
{
    public partial class ServiceHostSettings
    {
        public override string ToString()
        {
            return Id;
        }

        public ServiceConfig GetRawConfigData(string environment)
        {
            return new ServiceConfig
            {
                ServiceName = Name,
                Parameters = (from p in Parameters select p.GetRawConfigData(environment)).ToList(),
                IdentitySettings = ConfigSet.Environments.Single(x=>x.Name==environment).GetRawIdentityData()
            };
        }
    }
}