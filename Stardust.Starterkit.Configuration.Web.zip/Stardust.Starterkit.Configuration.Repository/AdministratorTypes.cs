﻿namespace Stardust.Starterkit.Configuration.Repository
{
    public enum AdministratorTypes
    {
        ConfigAdmin,
        SystemAdmin,
        ConfigReader
    }
}