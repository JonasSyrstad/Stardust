﻿using System.Linq;
using Stardust.Interstellar.ConfigurationReader;
using Stardust.Particles;

namespace Stardust.Starterkit.Configuration.Repository
{
    public partial class ConfigSet
    {
        public override string ToString()
        {
            return Id;
        }

        public ConfigurationSet GetRawConfigData(string environment)
        {
            return new ConfigurationSet
            {
                Created = Created,
                LastUpdated = LastUpdate,
                Environments = (from e in Environments select e.GetRawConfigData()).ToList(),
                SetName = Id,
                ParentSet = ParentConfigSet.IsInstance()?ParentConfigSet.Id:"",
                Endpoints = (from s in Services select s.GetRawConfigData(environment)).ToList(),
                Services = (from s in ServiceHosts select s.GetRawConfigData(environment)).ToList()
            };
        }

    }
}