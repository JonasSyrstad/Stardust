using System;
using System.Collections.Generic;
using System.Linq;
using Stardust.Interstellar.ConfigurationReader;
using Stardust.Particles;

namespace Stardust.Starterkit.Configuration.Repository
{
    public static class CreateEnvironmentExtentions
    {
        internal static readonly string[] ServiceParameters =
        {
            "Thumbprint","Address","Audience","IssuerAddress","StsAddress","IssuerMetadataAddress","IssuerActAsAddress","IssuerName","CertificateValidationMode","RequireHttps","EnforceCertificateValidation","Realm"};

        internal static readonly string[] PrServiceParameters = { "Address", "Key", "UserName", "ContainerName", "SenderName", "Port", "KeepAlive", "Metadata" };

        public static IEnvironment AddIdentitySettingsToEnvironment(this IEnvironment environment, ConfigurationContext context, IdentitySettings identitySettings)
        {
            if (identitySettings.IsNull()) return environment;
            context.SaveChanges();
            SetIdeneityValue(environment, "StsAddress", identitySettings.IssuerAddress);
            SetIdeneityValue(environment, "IssuerName", identitySettings.IssuerName);
            SetIdeneityValue(environment, "CertificateValidationMode", identitySettings.CertificateValidationMode);
            SetIdeneityValue(environment, "Thumbprint", identitySettings.Thumbprint);
            SetIdeneityValue(environment, "Audience", identitySettings.Audiences.FirstOrDefault());
            SetIdeneityValue(environment, "Realm", identitySettings.Realm);
            SetIdeneityValue(environment, "RequireHttps", identitySettings.RequireHttps.ToString().ToLower());
            SetIdeneityValue(environment, "EnforceCertificateValidation", identitySettings.EnforceCertificateValidation.ToString().ToLower());
            return environment;
        }

        private static void SetIdeneityValue(IEnvironment environment, string name, string value)
        {
            try
            {
                var param = environment.SubstitutionParameters.SingleOrDefault(x => x.Name == name);
                param.ItemValue = value;
            }
            catch (Exception)
            {
                throw new IndexOutOfRangeException(string.Format("Unable to find parameter {0}",name));
            }
        }

        public static IEnvironment CreateEnvironment(this IConfigSet configSet, ConfigurationContext context, string name, bool isImport = false)
        {
            var environment = context.Environments.Create();
            environment.ConfigSet = configSet;
            environment.ConfigSetNameId = configSet.Id;
            environment.Name = name;
            foreach (var serviceParameter in ServiceParameters)
            {
                environment.CreateSubstitutionParameters(context, serviceParameter, isImport);
            }
            context.SaveChanges();
            foreach (var service in configSet.Services)
            {
                var addressOverride = String.Format("{0}_Address", service.Name);
                var overrideProp = environment.SubstitutionParameters.SingleOrDefault(x => x.Name == addressOverride);
                if (overrideProp.IsNull())
                {
                    var subParam = environment.CreateSubstitutionParameters(context, addressOverride);
                    if (isImport)
                        subParam.ItemValue = "{0}";
                }
            }
            configSet.Environments.Add(environment);
            context.SaveChanges();
            AddToChildren(configSet, context, environment);
            return environment;
        }

        private static void AddToChildren(IConfigSet configSet, ConfigurationContext context, IEnvironment environment)
        {
            foreach (var childConfigSet in configSet.ChildConfigSets)
            {
                var c = childConfigSet;
                var child = environment.CreateChild(context,ref c);
                context.SaveChanges();
                AddToChildren(c, context, child);
            }
        }

        public static ISubstitutionParameter CreateSubstitutionParameters(this IEnvironment environment, ConfigurationContext context, string name, bool isImport = false)
        {
            var substitutionParameter = context.SubstitutionParameters.Create();
            substitutionParameter.EnvironmentNameId = environment.Id;
            substitutionParameter.Environment = environment;
            substitutionParameter.Name = name;
            if (name.EndsWith("_Address"))
            {
                var addressRoot = environment.SubstitutionParameters.SingleOrDefault(x => x.Name == "Address");
                if (addressRoot.IsInstance() && substitutionParameter.IsRoot)
                    substitutionParameter.Parent = addressRoot;
            }
            if ((name == "Address" || name == "Audience") && isImport)
                substitutionParameter.ItemValue = "{0}";
            environment.SubstitutionParameters.Add(substitutionParameter);
            return substitutionParameter;
        }

        public static IEnvironmentParameter CreateParameters(this IEnvironment environment, ConfigurationContext context, string name, bool isSecureString)
        {
            var substitutionParameter = context.EnvironmentParameters.Create();
            substitutionParameter.EnvironmentNameId = environment.Id;
            substitutionParameter.Environment = environment;
            substitutionParameter.Name = name;
            substitutionParameter.IsSecureString = isSecureString;
            return substitutionParameter;
        }

        public static void AddToChildren(this IEnvironment env, ConfigurationContext context, IEnvironmentParameter newPar)
        {
            foreach (var childEnvironment in env.ChildEnvironments)
            {
                var e = childEnvironment;
                var param = newPar.CreateChild(context, ref e);
                context.SaveChanges();
                AddToChildren(e, context, param);
            }
        }
    }
}