using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Stardust.Interstellar.ConfigurationReader;
using Stardust.Particles;
using Stardust.Particles.Collection;
using Stardust.Starterkit.Configuration.Business.CahceManagement;
using Stardust.Starterkit.Configuration.Repository;

namespace Stardust.Starterkit.Configuration.Business
{
    public class ConfigSetTask : IConfigSetTask
    {
        private readonly ICacheManagementService cacheController;
        private ConfigurationContext Repository;
        public ConfigSetTask(IRepositoryFactory repositoryFactory, ICacheManagementService cacheController)
        {
            this.cacheController = cacheController;
            this.cacheController.Initialize(this);
            Repository = repositoryFactory.GetRepository();
        }

        ~ConfigSetTask()
        {
            Dispose(false);
        }

        public bool CreateConfigSet(string name, string systemName, IConfigSet parent)
        {
            var configSets = from cs in Repository.ConfigSets where cs.Name == name && cs.System == systemName select cs;
            if (configSets.Count() != 0) throw new AmbiguousMatchException(string.Format("Config set '{0}\\{1}' already exists", name, systemName));
            if (parent.IsNull())
            {
                configSets = from cs in Repository.ConfigSets where cs.System == systemName select cs;
                if (configSets.Count() != 0) throw new AmbiguousMatchException(string.Format("Config set '{0}\\{1}'... system {1} already exists", name, systemName));
            }
            var configSet = Repository.ConfigSets.Create();
            if (parent.IsInstance())
            {
                foreach (var administrator in parent.Administrators)
                {
                    configSet.Administrators.Add(administrator);
                }
            }
            else
            {
                if (ConfigReaderFactory.CurrentUser != null)
                    configSet.Administrators.Add(ConfigReaderFactory.CurrentUser);
            }

            configSet.Name = name;
            configSet.Created = DateTime.UtcNow;
            configSet.System = systemName;
            configSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            if (parent.IsInstance())
            {

                configSet.ParentConfigSet = parent;
                foreach (var serviceDescription in parent.Services)
                {
                    var c = serviceDescription.CreateChild(Repository, ref configSet);
                    configSet.Services.Add(c);
                    Repository.SaveChanges();
                }
                foreach (var serviceHostSettingse in parent.ServiceHosts)
                {
                    var hostChild = serviceHostSettingse.CreateChild(Repository, ref configSet);
                    configSet.ServiceHosts.Add(hostChild);
                    Repository.SaveChanges();
                }
                foreach (var environment in parent.Environments)
                {
                    var child = environment.CreateChild(Repository, ref configSet);
                    configSet.Environments.Add(child);
                    Repository.SaveChanges();
                }
                Repository.SaveChanges();
                UpdateCache(configSet);
            }

            return true;
        }

        public IEndpoint CreateEndpoint(IServiceDescription service, string endpointname, List<string> parameters=null)
        {
            var endpoint = service.CreateEndpoint(Repository, endpointname,false,parameters);
            endpoint.ServiceDescription.ConfigSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            UpdateCache(service.ConfigSet);
            return endpoint;
        }

        private void UpdateCache(IConfigSet configSet)
        {
            foreach (var env in configSet.Environments)
            {
                Logging.DebugMessage("Updating cache for [{0}-{1}]",configSet.Name,env.Name);
                cacheController.TryUpdateCache(env.ConfigSet.Id, env.Name);
            }
        }

        public void CreateFromTextConfigStoreFile(ConfigurationSet configSet)
        {
            var newSet = Repository.ConfigSets.Create();
            newSet.Administrators.Add(ConfigReaderFactory.CurrentUser);
            newSet.Name = configSet.SetName;
            newSet.System = configSet.SetName;
            newSet.Created = DateTime.UtcNow;
            foreach (var e in configSet.Environments)
            {
                var env = newSet.CreateEnvironment(Repository, e.EnvironmentName, true);
                foreach (var p in e.Parameters)
                {
                    var param = env.CreateParameters(Repository, p.Name, p.BinaryValue.ContainsElements());
                    param.ItemValue = p.Value;
                    if (p.BinaryValue.ContainsElements())
                    {
                        param.BinaryValue = p.BinaryValue;
                        param.SetValue(Convert.ToBase64String(p.BinaryValue));
                    }
                }
                env.AddIdentitySettingsToEnvironment(Repository, (from s in configSet.Services where s.IdentitySettings != null select s.IdentitySettings).FirstOrDefault());
            }
            foreach (var s in configSet.Endpoints)
            {
                var service = newSet.CreateService(Repository, s.ServiceName);
                Repository.SaveChanges();
                foreach (var ep in s.Endpoints)
                {
                    var endpoint = service.CreateEndpoint(Repository, ep.BindingType, true);
                    endpoint.SetFromRawData(ep, Repository);
                }
                service.ClientEndpointValue = s.ActiveEndpoint;
            }
            if (configSet.Services.IsInstance())
            {
                foreach (var host in configSet.Services)
                {
                    try
                    {
                        var newHost = newSet.CreateServiceHost(Repository, host.ServiceName);
                        foreach (var configParameter in host.Parameters)
                        {
                            var param = newHost.CreateParameter(Repository, configParameter.Name, configParameter.BinaryValue.ContainsElements());
                            param.ItemValue = configParameter.BinaryValue.ContainsElements()
                                    ? Convert.ToBase64String(configParameter.BinaryValue)
                                    : configParameter.Value;
                            param.BinaryValue = configParameter.BinaryValue;
                        }
                    }
                    catch (Exception ex)
                    {

                        throw new InvalidDataException(string.Format("Unable to create {0}: {1}", host.ServiceName, ex.Message), ex);
                    }
                }
            }
            newSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
        }

        public IEnvironment CreatEnvironment(IConfigSet cs, string environmentName)
        {
            var env = cs.CreateEnvironment(Repository, environmentName);
            cs.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            return env;
        }

        public void CreatEnvironmentParameter(IEnvironment env, string name, string itemValue, bool isSecureString)
        {
            var newPar = env.CreateParameters(Repository, name, isSecureString);
            newPar.SetValue(itemValue);
            env.AddToChildren(Repository, newPar);
            env.ConfigSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            UpdateCache(env.ConfigSet);
        }

        public IServiceDescription CreateService(IConfigSet cs, string servicename)
        {
            var service = cs.CreateService(Repository, servicename);
            service.ConfigSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            UpdateCache(service.ConfigSet);
            return service;
        }

        public void Dispose()
        {
            Dispose(true);
        }

        public IEnumerable<IConfigSet> GetAllConfitSets()
        {
            if (ConfigReaderFactory.CurrentUser.AdministratorType != AdministratorTypes.SystemAdmin)
                return ConfigReaderFactory.CurrentUser.ConfigSet.ToList();
            var configSets = from cs in Repository.ConfigSets orderby cs.Id select cs;
            return configSets.ToList();
        }

        public IConfigSet GetConfigSet(string name, string systemName)
        {
            var configSet = GetConfigSetsWithName(name, systemName);
            return configSet.Single();
        }

        public IConfigSet GetConfigSet(string id)
        {
            var configSet = from cs in Repository.ConfigSets where cs.Id == id select cs;
            return configSet.Single();
        }

        public ConfigurationSet GetConfigSetData(string id, string environment)
        {

            ConfigurationSet set;
            if (!TryGetSetFromCache(id, environment, out set))
            {
                set = GetConfigSet(id).GetRawConfigData(environment);
                AddToCache(id, environment, set);
            }
            return set;
        }

        private void AddToCache(string id, string environment, ConfigurationSet set)
        {
            ConfigSetCache.AddOrUpdate(GetCacheKey(id, environment), set);
        }

        private static ConcurrentDictionary<string, ConfigurationSet> ConfigSetCache = new ConcurrentDictionary<string, ConfigurationSet>(new Dictionary<string, ConfigurationSet>());
        private bool TryGetSetFromCache(string id, string environment, out ConfigurationSet set)
        {
            ConfigurationSet item;
            if (!ConfigSetCache.TryGetValue(GetCacheKey(id, environment), out item))
            {
                set = null;
                return false;
            }
            if (item.LastUpdated <= GetConfigSet(id).LastUpdate)
            {
                set = null;
                return false;
            }
            set = item;
            return true;
        }

        private static string GetCacheKey(string id, string environment)
        {
            return string.Format("{0}[{1}]", id, environment);
        }

        public IEndpoint GetEndpoint(string id)
        {
            var ep= Repository.Endpoints.Single(x => x.Id == id);
            if (ep.Name == "custom")
            {
                foreach (var endpointParameter in ep.Parameters)
                {
                    endpointParameter.ConfigurableForEachEnvironment = true;
                    endpointParameter.IsPerService = true;
                }
                Repository.SaveChanges();
                UpdateCache(ep.ServiceDescription.ConfigSet);
            }
            return ep;
        }

        public IEndpointParameter GetEnpointParameter(string id)
        {
            return Repository.EndpointParameters.Single(x => x.Id == id);
        }

        public IEnvironment GetEnvironment(string id)
        {
            var env = Repository.Environments.Single(x => x.Id == id);
            foreach (var serviceHostSettingse in Repository.ServiceHostSettingss.Where(s => s.ConfigSetNameId == env.ConfigSetNameId))
            {
                if (env.SubstitutionParameters.All(s => s.Name != ServiceHostAddressSubstitutionName(serviceHostSettingse)))
                {
                    env.CreateSubstitutionParameters(Repository, ServiceHostAddressSubstitutionName(serviceHostSettingse));
                    Repository.SaveChanges();
                }
            }
            return env;
        }



        private static string ServiceHostAddressSubstitutionName(IServiceHostSettings serviceHostSettingse)
        {
            return string.Format("{0}_Address", serviceHostSettingse.Name);
        }

        public IEnvironmentParameter GetEnvironmentParameter(string id)
        {
            return Repository.EnvironmentParameters.Single(x => x.Id == id);
        }

        public IServiceDescription GetService(string id)
        {
            return Repository.ServiceDescriptions.Single(x => x.Id == id);
        }

        public ISubstitutionParameter GetSubstitutionParameter(string id)
        {
            return Repository.SubstitutionParameters.Single(x => x.Id == id);
        }

        public void UpdateEndpointParameter(IEndpointParameter parameter)
        {
            parameter.Endpoint.ServiceDescription.ConfigSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            UpdateCache(parameter.Endpoint.ServiceDescription.ConfigSet);
        }

        public void UpdateEnvironmentParameter(IEnvironmentParameter parameter)
        {
            parameter.Environment.ConfigSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            UpdateCache(parameter.Environment.ConfigSet);
        }

        public void UpdateService(IServiceDescription service)
        {
            service.ConfigSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            UpdateCache(service.ConfigSet);
        }

        public IServiceHostSettings GetServiceHost(string id)
        {
            return Repository.ServiceHostSettingss.Single(x => x.Id == id);
        }

        public IServiceHostSettings CreateServiceHost(IConfigSet configSet, string name)
        {
            var serviceHost = configSet.CreateServiceHost(Repository, name);
            configSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            UpdateCache(serviceHost.ConfigSet);
            return serviceHost;
        }

        public IServiceHostParameter CreateServiceHostParameter(IServiceHostSettings serviceHost, string name, bool isSecureString, string itemValue, bool isEnvironmental)
        {
            var param = serviceHost.CreateParameter(Repository, name, isSecureString);
            param.SetValue(itemValue);
            param.IsEnvironmental = isEnvironmental;
            param.ServiceHost.ConfigSet.LastUpdate = DateTime.UtcNow;
            if (param.IsEnvironmental)
            {
                foreach (var environment in serviceHost.ConfigSet.Environments)
                {
                    environment.CreateSubstitutionParameters(Repository, serviceHost.Name + "_" + param.Name);
                }
            }
            Repository.SaveChanges();
            UpdateCache(serviceHost.ConfigSet);
            return param;
        }

        public IServiceHostParameter GetHostParameter(string id)
        {
            return Repository.ServiceHostParameters.Single(x => x.Id == id);
        }

        public void UpdateHostParameter(IServiceHostParameter serviceHostParameter)
        {
            serviceHostParameter.ServiceHost.ConfigSet.LastUpdate = DateTime.UtcNow;
            if (serviceHostParameter.IsEnvironmental)
            {
                foreach (var environment in serviceHostParameter.ServiceHost.ConfigSet.Environments)
                {
                    var paramName = string.Format("{0}_{1}", serviceHostParameter.ServiceHost.Name, serviceHostParameter.Name);
                    var subParam = environment.SubstitutionParameters.SingleOrDefault(sp => sp.Name == paramName);
                    if(subParam.IsNull())
                        environment.CreateSubstitutionParameters(Repository,paramName );
                }
            }
            Repository.SaveChanges();
            UpdateCache(serviceHostParameter.ServiceHost.ConfigSet);
        }

        public void UpdateAdministrators(ICollection<IConfigUser> administrators)
        {
            Repository.SaveChanges();
        }

        public void UpdateCacheSettingsParameter(ICacheSettings cacheType)
        {
            cacheType.Environment.ConfigSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            UpdateCache(cacheType.Environment.ConfigSet);
        }

        public void DeleteSubstitutionParameter(string envirionmentId, string parameterId)
        {
            var env = GetEnvironment(envirionmentId);
            var subParam = GetSubstitutionParameter(parameterId);
            env.SubstitutionParameters.Remove(subParam);
            Repository.DeleteObject(subParam);
            Repository.SaveChanges();
            UpdateCache(env.ConfigSet);
        }

        public void CreateEndpointParameter(string item, string name, string itemValue, bool isSubstiturtionParameter)
        {
            var endpoint = GetEndpoint(item);
            endpoint.AddParameter(Repository, name, itemValue, isSubstiturtionParameter);
            Repository.SaveChanges();
            UpdateCache(endpoint.ServiceDescription.ConfigSet);
        }

        public void DeleteEndpoint(IEndpoint endpoint)
        {
            var configSet = endpoint.ServiceDescription.ConfigSet;
            Repository.DeleteObject(endpoint);
            Repository.SaveChanges();
            UpdateCache(configSet);
        }

        public void UpdateSubstitutionParameter(ISubstitutionParameter parameter)
        {
            parameter.Environment.ConfigSet.LastUpdate = DateTime.UtcNow;
            Repository.SaveChanges();
            UpdateCache(parameter.Environment.ConfigSet);
        }

        private void Dispose(bool disposing)
        {
            if (disposing) GC.SuppressFinalize(this);
            if (Repository != null) Repository.Dispose();
        }

        private IQueryable<IConfigSet> GetConfigSetsWithName(string name, string systemName)
        {
            var configSet = from cs in Repository.ConfigSets where cs.Name == name && cs.System == systemName select cs;
            return configSet;
        }
    }
}