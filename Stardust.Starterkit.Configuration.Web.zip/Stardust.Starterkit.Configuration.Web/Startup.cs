﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Stardust.Starterkit.Configuration.Web.Startup))]
namespace Stardust.Starterkit.Configuration.Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
