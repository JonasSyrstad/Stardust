﻿using System;
using System.Web.Routing;
using Stardust.Particles;
using Stardust.Starterkit.Configuration.Business;
using Stardust.Starterkit.Configuration.Repository;
using System.Web.Mvc;

namespace Stardust.Starterkit.Configuration.Web.Controllers
{
    [Authorize]
    public class ServiceController : BaseController
    {
        public ActionResult Create(string id, string command)
        {
            var cs = ConfigReaderFactory.GetConfigSetTask().GetConfigSet(command);
            if (!cs.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            ViewBag.Name = cs.Name;
            ViewBag.System = cs.System;
            return View();
        }

        [HttpPost]
        public ActionResult Create(string id, string command, ServiceDescription model)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var cs = reader.GetConfigSet(command);
            if (!cs.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            ViewBag.Name = cs.Name;
            ViewBag.System = cs.System;
            reader.CreateService(cs, model.Name);
            return RedirectToAction("Details", "ConfigSet", new { name = cs.Name, system = cs.System });
        }

        public ActionResult Details(string id, string item)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask(); 
            var service = reader.GetService(item);
            if (!service.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            ViewBag.Name = service.ConfigSet.Name;
            ViewBag.System = service.ConfigSet.System;
            ViewBag.ServiceId = service.Id;
            return View(service);
        }

        [HttpPost]
        public ActionResult Details(string id, string item,ServiceDescription model)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var service = reader.GetService(item);
            if (!service.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            service.ClientEndpointValue = model.ClientEndpointValue;
            reader.UpdateService(service);
            return RedirectToAction("Details", "ConfigSet", new { name = service.ConfigSet.Name, system = service.ConfigSet.System });
        }

        public ActionResult Delete(string id)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var endpoint = reader.GetEndpoint(id);
            return View(endpoint);
        }

        [HttpPost]
        public ActionResult Delete(string id,Endpoint model)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var endpoint = reader.GetEndpoint(id);
            reader.DeleteEndpoint(endpoint);
            return RedirectToAction("Details", new {id = "edit", item = endpoint.ServiceNameId});
        }
    }
}