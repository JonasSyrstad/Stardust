﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using Stardust.Interstellar;
using Stardust.Particles;
using Stardust.Particles.Xml;
using Stardust.Starterkit.Configuration.Business;

namespace Stardust.Starterkit.Configuration.Web.Controllers
{
    public class RegistrationController : Controller
    {
        [HttpPost]
        public ActionResult TryAddService(string serviceMetadata)
        {
            try
            {
                if (serviceMetadata.IsNullOrWhiteSpace())
                {
                    using (var tr = new StreamReader(Request.InputStream))
                    {
                        serviceMetadata = tr.ReadToEnd();
                    }
                }
                var data = Deserializer<ServiceRegistrationServer.ServiceRegistrationMessage>.Deserialize(serviceMetadata);
                var reader = ConfigReaderFactory.GetConfigSetTask();
                var cs = reader.GetConfigSet(data.ConfigSetId);
                var service = (from s in cs.Services where s.Name == data.ServiceName select s).SingleOrDefault();
                if (service.IsNull())
                {
                    service = reader.CreateService(cs, data.ServiceName);
                    reader.CreateEndpoint(service, data.DefaultBinding, data.Properties);
                    var env = (from e in cs.Environments where e.Name == data.Environment select e).SingleOrDefault();
                    if (env.IsNull())
                    {
                        env = reader.CreatEnvironment(cs, data.Environment);
                    }
                    var serviceRoot = (from sp in env.SubstitutionParameters where sp.Name == string.Format("{0}_Address", data.ServiceName) select sp).SingleOrDefault();
                    if (serviceRoot.IsNull() && data.DefaultEnvirionmentUrlPath.ContainsCharacters())
                        serviceRoot.ItemValue = data.DefaultEnvirionmentUrlPath;

                }
                return Json("OK");
            }
            catch (Exception exception)
            {
                Logging.Exception(exception);
                return Json(string.Format("Error: {0}", exception.Message));
            }
        }
    }
}