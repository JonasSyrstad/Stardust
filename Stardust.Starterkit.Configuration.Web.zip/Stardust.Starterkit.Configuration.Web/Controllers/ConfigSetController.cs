﻿using System;
using System.Web;
using System.Web.Mvc;
using Stardust.Interstellar.ConfigurationReader;
using Stardust.Particles;
using Stardust.Particles.Xml;
using Stardust.Starterkit.Configuration.Business;
using Stardust.Starterkit.Configuration.Repository;

namespace Stardust.Starterkit.Configuration.Web.Controllers
{
   
    public class ConfigSetController : BaseController
    {

        [Authorize]
        public ActionResult Details(string name, string system)
        {
            var cs = ConfigReaderFactory.GetConfigSetTask().GetConfigSet(name, system);
            if(!cs.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            ViewBag.Id = cs.Id;
            return View(cs);
        }

        [Authorize]
        public ActionResult Create(string id1, string id2)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            IConfigSet parent = null;

            if (id1.ContainsCharacters())
                parent = reader.GetConfigSet(id1, id2);
            if (parent == null)
            {
                if (ConfigReaderFactory.CurrentUser.AdministratorType != AdministratorTypes.SystemAdmin) throw new UnauthorizedAccessException("Access denied to configset");
                ViewBag.IsNew = true;
                ViewBag.CreateType = "new";
            }
            else
            {
                if (!parent.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
                ViewBag.IsNew = false;
                ViewBag.CreateType = string.Format("child for {0}.{1}", id1, id2);
            }
            return View(parent);
        }


         [Authorize]
        [HttpPost]
        public ActionResult Create(string id1, string id2, ConfigSet model)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            IConfigSet parent = null;
            if (id1.ContainsCharacters())
            {
                parent = reader.GetConfigSet(id1, id2);
                if (!parent.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            }
            else
            {
                if (ConfigReaderFactory.CurrentUser.AdministratorType != AdministratorTypes.SystemAdmin) throw new UnauthorizedAccessException("Access denied to configset");
            }
            reader.CreateConfigSet(model.Name, string.IsNullOrEmpty(model.System) ? id2 : model.System  , parent);
            var csId = reader.GetConfigSet(model.Name, string.IsNullOrEmpty(model.System) ? id2 : model.System);
            return RedirectToAction("Details", "ConfigSet", new { name = csId.Name, system = csId.System });
        }

         [Authorize(Roles = "SystemAdmin")]
        [HttpGet]
        public ActionResult Upload()
        {
            return View();
        }

         [Authorize(Roles = "SystemAdmin")]
        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase file)
        {
            var data = Deserializer<ConfigurationSets>.Deserialize(file.InputStream,"http://pragma.no/Pragma.Core.Services.ConfigurationReader.ConfigurationSets");
            var reader = ConfigReaderFactory.GetConfigSetTask();
            foreach (var configSet in data.ConfigSets  )
            {
                reader.CreateFromTextConfigStoreFile(configSet);
            }
            return RedirectToAction("Index", "Home");
        }
    }
}
