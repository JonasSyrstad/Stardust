﻿using System;
using System.Web.Mvc;
using Stardust.Starterkit.Configuration.Business;
using Stardust.Starterkit.Configuration.Repository;
using Stardust.Wormhole;
using Environment = Stardust.Starterkit.Configuration.Repository.Environment;

namespace Stardust.Starterkit.Configuration.Web.Controllers
{
    public class EnvironmentController : BaseController
    {
        [Authorize]
        public ActionResult Details(string id, string item)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var env = reader.GetEnvironment(item);
            if (!env.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            ViewBag.Name = env.ConfigSet.Name;
            ViewBag.System = env.ConfigSet.System;
            ViewBag.EnvironmentId = env.Id;
            return View(reader.GetEnvironment(item));
        }

        public ActionResult Create(string id, string item)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var cs = reader.GetConfigSet(item);
            if (!cs.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            ViewBag.Name = cs.Name;
            ViewBag.System = cs.System;
            return View((object)null);
        }

        [HttpPost]
        public ActionResult Create(string id, string item, Environment model)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var cs = reader.GetConfigSet(item);
            if (!cs.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            var env = reader.CreatEnvironment(cs, model.Name);
            ViewBag.Name = cs.Name;
            ViewBag.System = cs.System;
            return RedirectToAction("Details", new { id = "edit", item = env.Id });
        }

        [HttpGet]
        public ActionResult Caching(string id, string item)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            ViewBag.Id = item;
            return View(reader.GetEnvironment(item).CacheType);
        }

        [HttpPost]
        public ActionResult Caching(string id, string item,CacheSettings model)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var env = reader.GetEnvironment(item);
            //env.CacheType.CacheImplementation = model.CacheImplementation;
            //env.CacheType.Secure = model.Secure;
            //env.CacheType.MachineNames = model.MachineNames;
            //env.CacheType.Port = model.Port;
            //env.CacheType.PassPhrase = model.PassPhrase;
            //env.CacheType.Port = model.Port;
            //env.CacheType.CacheName = model.CacheName;
            model.Map().To(env.CacheType);
            reader.UpdateCacheSettingsParameter(env.CacheType);
            return RedirectToAction("Details", new { id = "edit", item = env.Id });
        }
    }
}