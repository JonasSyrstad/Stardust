﻿using System;
using Stardust.Starterkit.Configuration.Business;
using Stardust.Starterkit.Configuration.Repository;
using System.Web.Mvc;

namespace Stardust.Starterkit.Configuration.Web.Controllers
{
    public class ServiceHostsController : BaseController
    {
        [Authorize]
        public ActionResult Details(string id)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var serviceHost = reader.GetServiceHost(id);
            if (!serviceHost.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            ViewBag.Name = serviceHost.ConfigSet.Name;
            ViewBag.System = serviceHost.ConfigSet.System;
            ViewBag.HostId = serviceHost.Id;
            return View(serviceHost);
        }

        public ActionResult Create(string id)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var configSet = reader.GetConfigSet(id);
            if (!configSet.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            ViewBag.Id = configSet.Id;
            ViewBag.Name = configSet.Name;
            ViewBag.System = configSet.System;
            return View((object)null);
        }
        [HttpPost]
        public ActionResult Create(string id, ServiceHostSettings model)
        {
            var reader = ConfigReaderFactory.GetConfigSetTask();
            var configSet = reader.GetConfigSet(id);
            if (!configSet.UserHasAccessTo()) throw new UnauthorizedAccessException("Access denied to configset");
            ViewBag.Id = configSet.Id;
            var serviceHost = reader.CreateServiceHost(configSet, model.Name);
            return RedirectToAction("Details", new { id = serviceHost.Id });
        }
    }
}