﻿using System.ComponentModel.DataAnnotations;

namespace Stardust.Starterkit.Configuration.Web.Models
{
    public class EndpointPropertyModel
    {
        public string Name { get; set; }

        public string ItemValue { get; set; }

        public bool IsSubstiturtionParameter { get; set; }

    }
}