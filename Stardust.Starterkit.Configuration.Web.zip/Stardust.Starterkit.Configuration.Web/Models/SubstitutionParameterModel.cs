﻿using System.Collections.Generic;
using System.Linq;

namespace Stardust.Starterkit.Configuration.Web.Models
{
    public class SubParKey
    {
        public string Category { get; set; }
        public int Type { get; set; }
    }
    public class SubstitutionParameterModel
    {
        public string EnvironmentNameId { get; set; }
        public string Id { get; set; }
        public bool IsInherited { get; set; }
        public bool IsRoot { get; set; }
        public string Value { get; set; }
        public string ItemValue { get; set; }
        public string Name { get; set; }

        public int Type { get { return Category == "Common" ? 1 : 2; } }

        public string DisplayName
        {
            get
            {
                if (Name.Contains("_"))
                {
                    var val = Name.Split('_');
                    return val.Last();
                }
                return Name;
            }
        }

        public string SortCategory
        {
            get
            {
                if (Name.Contains("_"))
                {
                    var val = Name.Split('_');
                    if (val.Length == 2)
                        return "2 " + val[0];
                    if (val.Length > 2)
                    {
                        var data = new List<string>();
                        for (int i = 0; i < val.Length - 1; i++)
                        {
                            data.Add(val[i]);
                        }
                        return "2 "+string.Join("_", data);
                    }
                }

                return "1 Common";
            }
        }
        public string Category
        {
            get
            {
                if (Name.Contains("_"))
                {
                    var val = Name.Split('_');
                    if (val.Length == 2)
                        return val[0];
                    if (val.Length > 2)
                    {
                        var data = new List<string>();
                        for (int i = 0; i < val.Length - 1; i++)
                        {
                            data.Add(val[i]);
                        }
                        return string.Join("_", data);
                    }
                }
                
                return "Common";
            }
        }
    }

    public static class Helper
    {
        public static string RemoveSortHelper(this string value)
        {
            return value.Replace("1 ", "").Replace("2 ", "");
        }
    }
}