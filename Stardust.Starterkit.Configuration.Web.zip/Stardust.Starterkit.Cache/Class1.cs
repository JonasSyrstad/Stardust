﻿using Stardust.Interstellar.ConfigurationReader;
using Stardust.Particles;

namespace Stardust.Starterkit.Cache
{
    public class CachedStarterkitReader:StarterkitConfigurationReader
    {
        private ICacheController cacheController;

        public CachedStarterkitReader(ICacheController cacheController)
        {
            this.cacheController = cacheController;
        }

        protected override bool GetSettingsFromCache(string setName, string environment, out ConfigurationSet item)
        {
            return cacheController.TryGetCachedItem(GetItemKey(setName, environment), out item);
        }

        protected override void SaveConfigSetToCache(string setName, string environment, bool faultedMemCache, ConfigurationSet item)
        {
            if (!cacheController.TrySaveCachedItem(GetItemKey(setName, environment), item))
            {
                Logging.DebugMessage("ConfigSet cache updated [REDIS]");
            }
        }

        private static string GetItemKey(string setName, string environment)
        {
            return string.Format("CS:{0}_{1}", setName, environment);
        }
    }

}
