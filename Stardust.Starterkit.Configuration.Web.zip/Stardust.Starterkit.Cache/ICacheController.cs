﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using StackExchange.Redis;
using Stardust.Interstellar;
using Stardust.Interstellar.ConfigurationReader;
using Stardust.Particles;

namespace Stardust.Starterkit.Cache
{
    public interface ICacheController
    {


        bool TryGetCachedItem(string itemKey, out ConfigurationSet item);
        bool TrySaveCachedItem(string itemKey, ConfigurationSet item);
    }

    public class CacheController : ICacheController
    {
        private static readonly object triowing = new object();
        private const string connectionStringFormat = "{0},ssl={1},password={2}";
        private static ConnectionMultiplexer multiplexer;

        public CacheController(IRuntime runtime)
        {
            lock (triowing)
            {
                if (multiplexer.IsNull())
                    multiplexer = ConnectionMultiplexer.Connect(GetConnectionString(runtime.Context.GetEnvironmentConfiguration().Cache));
            }
        }

        private static string GetConnectionString(CacheSettings caceSettings)
        {
            return string.Format(connectionStringFormat, caceSettings.MachineNames, caceSettings.Secure.ToString().ToLower(), caceSettings.PassPhrase);
        }

        public bool TryGetCachedItem(string itemKey, out ConfigurationSet item)
        {
            item = null;
            var dataItem = GetDataStore().StringGet(itemKey);
            if (dataItem.HasValue)
            {
                item = JsonConvert.DeserializeObject<ConfigurationSet>(dataItem.ToString());
            }
            return dataItem.HasValue;
        }

        private static IDatabase GetDataStore()
        {
            return multiplexer.GetDatabase();
        }

        public bool TrySaveCachedItem(string itemKey, ConfigurationSet item)
        {
            try
            {
                GetDataStore().StringSet(itemKey, JsonConvert.SerializeObject(item));
                Logging.DebugMessage("configset '{0}' added to cache {1}",itemKey,GetDataStore().Database);
                return true;
            }
            catch (Exception ex)
            {
                Logging.Exception(ex, "Faulted cache [REDIS]");
                return false;
            }
        }
    }
}