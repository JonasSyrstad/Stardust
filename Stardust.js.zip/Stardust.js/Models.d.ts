declare namespace Stardust.js {
}
