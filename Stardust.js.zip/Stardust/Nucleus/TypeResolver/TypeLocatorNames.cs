﻿namespace Stardust.Nucleus.TypeResolver
{
    internal class TypeLocatorNames
    {
        internal const string DefaultName = "default";
    }
}