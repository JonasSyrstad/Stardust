using System;

namespace Stardust.Nucleus.TypeResolver
{
    /// <summary>
    /// Kernel scope control 
    /// </summary>
    public interface IKernelContext : IDisposable
    {

    }
}