﻿Remember to add the following to your machine.config's

<appSettings>
	<add key="stardust.configUser" value="sdUser"/>
	<add key="stardust.configPassword" value="**********"/>
	<add key="stardust.configDomain" value="EAZYPORTCONFIG"/>
	<add key="configSet" value=" v1-StardustSample "/>
	<add key="environment" value="Dev"/>
	<add key="stardust.configLocation" value=" https://config.stardustframework.com/" />
</appSettings>
