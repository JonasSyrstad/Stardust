using System.ServiceModel;
using Stardust.Core.Wcf;

namespace Stardust.Interstellar.DefaultImplementations
{
    internal class ServiceHostBehaviorConfiguration : IServiceHostBehaviour
    {
        public void SetThrottling(ServiceHost selfConfiguringHost)
        {

        }

        public void ConfigureBehaviours(ServiceHost selfConfiguringHost)
        {

        }
    }
}