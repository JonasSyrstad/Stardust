using System;

namespace Stardust.Nucleus.ContextProviders
{
    public interface IExtendedScopeProvider : IScopeProviderBase, IControlledProvider, IDisposable
    {

    }
}