﻿namespace Stardust.Core.BatchProcessor
{
    public enum UpdateTypes
    {
        Unchanged,
        Add,
        Update,
        Delete,
        ExportError
    }
}