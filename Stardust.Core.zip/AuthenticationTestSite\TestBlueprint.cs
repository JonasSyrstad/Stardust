using System.Globalization;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json;
using Stardust.Core;
using Stardust.Core.Default.Implementations;
using Stardust.Interstellar;
using Stardust.Interstellar.ConfigurationReader;
using Stardust.Interstellar.Serializers;
using Stardust.Interstellar.Utilities;

namespace AuthenticationTestSite
{
    public class TestBlueprint:Blueprint
    {
        protected sealed override void SetDefaultBindings()
        {
            //Setting default JsonSettings
            JsonConvert.DefaultSettings = () => new JsonSerializerSettings
                                                    {
                                                        NullValueHandling = NullValueHandling.Ignore,
                                                        DateFormatHandling = DateFormatHandling.IsoDateFormat,
                                                        DateTimeZoneHandling = DateTimeZoneHandling.Utc,
                                                        Culture = CultureInfo.InvariantCulture,

                                                    };
            Configurator.Bind<IConfigurationReader>().To<StarterkitConfigurationReader>();
            Configurator.Bind<IReplaceableSerializer>().To<ProtobufReplaceableSerializer>().SetSingletonScope();
            ServicePointManager.ServerCertificateValidationCallback = CertificateValidation;
            Bind<IUrlFormater, UrlFormater>().SetSingletonScope().AllowOverride = false;
            Configurator.Bind<IServiceTearDown>().To<DefaultServiceTearDown>().SetSingletonScope();
            Configurator.Bind<IStardustWebInitializer>().To<WebInitializer>().SetTransientScope();
        }

        /// <summary>
        /// Place your bindings here
        /// </summary>
        protected override void DoCustomBindings()
        {
        }
        private bool CertificateValidation(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return sslPolicyErrors == SslPolicyErrors.None || certificate.Subject.Contains("terstest1-vm1.cloudapp.net");
        }
    }
}