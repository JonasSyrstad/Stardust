﻿//
// CsvTableParser.cs
// This file is part of Stardust
//
// Author: Jonas Syrstad (jsyrstad2+StardustCore@gmail.com), http://no.linkedin.com/in/jonassyrstad/) 
// Copyright (c) 2014 Jonas Syrstad. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using Stardust.Clusters;

namespace Stardust.Particles.TableParser
{
    public class CsvTableParser : DynamicConfigurableObjectBase, ITableParser
    {
        private string Delimiter;
        private string RowBreak;
        private string TextQualifier;
        private bool IsFirstRowHeaders;

        public CsvTableParser()
            : base(null)
        {
            Delimiter = "|";
            RowBreak = Environment.NewLine;
            TextQualifier = "\"";
            IsFirstRowHeaders = true;
        }

        public ITableParser Initialize(string delimiter, string rowBreak, string textQualifier, bool isFirstRowHeaders)
        {
            Delimiter = delimiter;
            RowBreak = rowBreak;
            TextQualifier = textQualifier;
            IsFirstRowHeaders = isFirstRowHeaders;
            return this;
        }

        public Document Parse(string fileName)
        {
            var content = EncodingFactory.ReadFileText(fileName);
            return ParseFileContent(content);
        }

        private Document ParseFileContent(string content)
        {
            var doc = new Document();
            var isFirst = true;
            var rows = content.Split(RowBreak.ToCharArray());
            foreach (var row in rows)
            {
                if (row.IsNullOrWhiteSpace()) continue;
                if (isFirst && IsFirstRowHeaders)
                    doc.SetHeaders(ParseRow(row, doc));
                else
                    doc.Add(ParseRow(row, doc));
                isFirst = false;
            }
            return doc;
        }

        private DocumentRow ParseRow(string row, Document document)
        {
            var documentRow = new DocumentRow(document);
            var rowContent = row.Replace("\r", "").Split(Delimiter.ToCharArray());
            foreach (var collumn in GetCells(rowContent))
                documentRow.Add(collumn);
            return documentRow;
        }

        private IEnumerable<string> GetCells(IEnumerable<string> lineCells)
        {
            var cells = new List<string>();
            var joinNexCell = false;
            foreach (var lineCell in lineCells)
            {
                if (joinNexCell)
                {
                    joinNexCell = !lineCell.EndsWithCaseInsensitive(TextQualifier);
                    cells[cells.Count() - 1] += Delimiter + RemoveTextQualifier(lineCell);
                    continue;
                }
                if (ShouldJoinCells(lineCell))
                    joinNexCell = true;
                cells.Add(RemoveTextQualifier(lineCell));
            }
            return cells;
        }

        private bool ShouldJoinCells(string lineCell)
        {
            return TextQualifier.ContainsCharacters()
                && (lineCell.StartsWithCaseInsensitive(TextQualifier)
                && !lineCell.EndsWithCaseInsensitive(TextQualifier));
        }

        private string RemoveTextQualifier(string lineCell)
        {
            if (TextQualifier.ContainsCharacters())
                return lineCell.Replace(TextQualifier, "");
            return lineCell;
        }

        [ExcludeFromCodeCoverage]
        public Document Parse(Stream stream)
        {
            var content = EncodingFactory.ReadFileText(stream);
            return ParseFileContent(content);
        }

        [ExcludeFromCodeCoverage]
        public Document Parse(byte[] buffer)
        {
            var content = EncodingFactory.ReadFileText(buffer);
            return ParseFileContent(content);
        }

        [ExcludeFromCodeCoverage]
        public ITableParser SetDelimiter(string delimiter)
        {
            Delimiter = delimiter;
            return this;
        }

        [ExcludeFromCodeCoverage]
        public ITableParser SetRowBreak(string rowBreak)
        {
            RowBreak = rowBreak;
            return this;
        }

        [ExcludeFromCodeCoverage]
        public ITableParser SetTextQualifier(string textQualifier)
        {
            TextQualifier = textQualifier;
            return this;
        }

        [ExcludeFromCodeCoverage]
        public ITableParser SetHeaderRow(bool isFirstRowHeaders)
        {
            IsFirstRowHeaders = isFirstRowHeaders;
            return this;
        }

        public bool IsSuitableForFile(string fileName)
        {
            return fileName.EndsWithCaseInsensitive("csv")
                || fileName.EndsWithCaseInsensitive("txt");
        }

        public Parsers GetParserType()
        {
            return Parsers.Delimitered;
        }
    }
}