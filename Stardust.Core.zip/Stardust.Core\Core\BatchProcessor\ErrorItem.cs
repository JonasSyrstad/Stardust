﻿namespace Stardust.Core.BatchProcessor
{
    public class ErrorItem
    {
    }
}