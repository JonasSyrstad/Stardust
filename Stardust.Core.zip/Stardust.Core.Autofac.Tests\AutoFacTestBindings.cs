﻿using Stardust.Interstellar;

namespace Stardust.Core.Autofac.Tests
{
    public class AutoFacTestBindings:Blueprint
    {
        protected override void DoCustomBindings()
        {
        }
    }
}
