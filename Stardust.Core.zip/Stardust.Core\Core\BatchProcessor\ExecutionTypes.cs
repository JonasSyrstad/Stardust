﻿namespace Stardust.Core.BatchProcessor
{
    public enum ExecutionTypes
    {
        Full,
        Delta
    }
}