﻿namespace Stardust.Core.BatchProcessor
{
    public class EnvironmentDefinition
    {
        public string Name { get; set; }
    }
}
