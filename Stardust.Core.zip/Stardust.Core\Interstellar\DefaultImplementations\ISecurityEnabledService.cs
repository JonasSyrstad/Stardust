namespace Stardust.Interstellar.DefaultImplementations
{
    public interface ISecurityEnabledService
    {

    }
}