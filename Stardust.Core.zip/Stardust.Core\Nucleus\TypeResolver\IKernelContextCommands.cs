﻿namespace Stardust.Nucleus.TypeResolver
{
    internal interface IKernelContextCommands
    {
        void End();
    }
}